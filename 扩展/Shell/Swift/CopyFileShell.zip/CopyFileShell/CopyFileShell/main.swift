
/// 功用:
/// 通过输入目标目录与最终目录, 实现对目标目录下所有.h文件创建替身并移动到最终目录的批量操作

import Foundation
import ArgumentParser

struct DirectoryCommand: ParsableCommand {

    // @Argument(help: "The symbolic directory of operate directory") var symbolic: String
    // @Argument(help: "The operate directory") var operate: String

    @Option(name: .shortAndLong, help: "The symbolic directory of operate directory") var symbolic: String

    @Option(name: .shortAndLong, help: "The operate directory") var operate: String


    mutating func run() throws {
        self.startSymbolic()
    }

    /// 直接链接
    mutating func startSymbolic() {
        print("--------------------------------------------------")
        /// 完整链接
        if !operate.hasSuffix("/") { self.operate += "/" }
        if !symbolic.hasSuffix("/") { self.symbolic += "/" }

        /// 开始处理
        let manager = FileManager.default
        manager
            .subpaths(atPath: operate)?
            .filter({
                $0.hasSuffix(".h")
            })
            .forEach({
                // 得到文件名称
                if let filename = $0.components(separatedBy: "/").last, !filename.isEmpty {
                    try? manager.createSymbolicLink(atPath: self.symbolic + filename, withDestinationPath: self.operate + $0)
                }
            })
        print("--------------------------------------------------")
    }
}

 DirectoryCommand.main()


/*
 /// 获取参数
 let args = ProcessInfo.processInfo.arguments
 args.forEach { print($0 + "😿") }
 func symbolicTest() {
     // 原始操作目录
     let operatePath = NSHomeDirectory() + "/Desktop/TestCopy/Core/"
     let includePath = NSHomeDirectory() + "/Desktop/TestCopy/include/"

     print("--------------------------------------------------")
     let manager = FileManager.default
     manager
         .subpaths(atPath: operatePath)?
         .filter({
             $0.hasSuffix(".h")
         })
         .forEach({
             // 得到文件名称
             if let filename = $0.components(separatedBy: "/").last {
                 let symbolicPath = includePath + filename
                 try? manager.createSymbolicLink(atPath: symbolicPath, withDestinationPath: operatePath + $0)
             }
         })
     print("--------------------------------------------------")

 }

 symbolicTest()
 */
