#### fir upgrade

`fir upgrade` 指令用于升级最新版本的 fir-cli

```sh
$ fir upgrade
```
