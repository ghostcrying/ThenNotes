# encoding: utf-8

require_relative './patches/blank'
require_relative './patches/concern'
require_relative './patches/hash'
require_relative './patches/instance_variables'
require_relative './patches/native_patch'
require_relative './patches/os_patch'
require_relative './patches/try'
require_relative './patches/default_headers'
