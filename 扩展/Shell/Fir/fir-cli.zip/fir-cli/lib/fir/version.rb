# encoding: utf-8

module FIR
  VERSION = '2.0.14'
end
