# encoding: utf-8
# This file exists for backward compatbility with require 'fir-cli'
require_relative './fir'
